import { test, expect } from '@playwright/test';

// write test
test('loops in Playwright Test', async ({ page }) => {
  // go to website
  await page.goto('https://github.com/BakkappaN');

 const repolinks=await page.$$('.repo');
//  for(const link of repolinks){
//     const text=await link.innerText();
//     console.log('loop1 : '+text);
//   }
  
 for(let i=0;i<repolinks.length;i++){ 
    const text=await repolinks[i].textContent();
    console.log('loop2 : '+text);
  }
});