import { test, expect } from '@playwright/test';

// write test
test('Get text and attribute values', async ({ page }) => {
  // go to website
  await page.goto('https://github.com/BakkappaN/');
    const name=await page.locator('[itemprop="name"]').textContent();
    console.log("Name is : "+name);
 
});

