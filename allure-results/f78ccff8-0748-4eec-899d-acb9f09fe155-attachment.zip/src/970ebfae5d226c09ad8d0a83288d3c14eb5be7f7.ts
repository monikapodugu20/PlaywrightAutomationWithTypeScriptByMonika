import { test, expect } from '@playwright/test';
import path from 'path';
import fs from 'fs';
import {parse} from 'csv-parse/sync';
type Record = {
  skill1: string;
  skill2: string;
};
const records = parse
(fs.readFileSync(path.join(__dirname, '../../test-data/QA/testdata.csv'), 'utf8'), 
    {
    columns: true,
    skip_empty_lines: true
    }
)as Record[];

// write test
test('csv Playwright Test', async ({ page }) => {
  // go to website
  await page.goto('https://www.wikipedia.org/');

  // search keywords
  const searchBox = page.getByRole('searchbox', { name: 'Search Wikipedia' });
  //await searchBox.fill('' + testData.TestData.skill1);
  await searchBox.fill(String((records[0] as { skill1: string }).skill1));
  await searchBox.press('Enter');

  // click on article link
  await page.getByRole('link', { name: 'Playwright' }).first().click();

  // validate page title
  await expect(page).toHaveTitle(/Playwright/);
});