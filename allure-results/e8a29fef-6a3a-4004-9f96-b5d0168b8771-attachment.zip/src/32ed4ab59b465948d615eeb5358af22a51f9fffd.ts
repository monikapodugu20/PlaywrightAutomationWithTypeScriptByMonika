import { test, expect } from '@playwright/test';
import PostApiRequest from '../../test-data/api_requests/POST_request.json';

test.use({ baseURL: process.env.BASE_API_URL });//Accessing the base url from .env file
// write test
test('Create POST API Request using static file in Plywright Typescript', async ({ request }) => {

    //create post api request
    const postapiresponse = await request.post('/booking', { data: PostApiRequest });
    const jsonpostapiresponse = await postapiresponse.json();//will convert postapi response into json format
    console.log(`POST API Response : ${JSON.stringify(jsonpostapiresponse)}`);//will print after converting into string
    
    // Validating api response
    expect(postapiresponse.status()).toBe(200);
    expect(postapiresponse.statusText()).toBe('OK');
    expect(postapiresponse.headers()['content-type']).toContain('application/json');

    // Validate propert/key names
    expect(jsonpostapiresponse).toHaveProperty('bookingid');
    expect(jsonpostapiresponse).toHaveProperty('booking');
    expect(jsonpostapiresponse.booking).toHaveProperty('firstname', 'Monika');
    expect(jsonpostapiresponse.booking).toHaveProperty('lastname', 'Sharma');
    expect(jsonpostapiresponse.booking).toHaveProperty('totalprice', 100);
    expect(jsonpostapiresponse.booking).toHaveProperty('depositpaid', true);
    expect(jsonpostapiresponse.booking).toHaveProperty('bookingdates');
    expect(jsonpostapiresponse.booking.bookingdates).toHaveProperty('checkin', '2023-01-01');
    expect(jsonpostapiresponse.booking.bookingdates).toHaveProperty('checkout', '2023-01-05');
});