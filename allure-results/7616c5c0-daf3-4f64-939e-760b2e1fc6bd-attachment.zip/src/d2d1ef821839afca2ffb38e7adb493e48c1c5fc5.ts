import { Locator, Page } from "@playwright/test"

export class HomePage {
    readonly page: Page;
    readonly searchBox: Locator;
    readonly searchButton: Locator;
    
    constructor(page: Page) {
        this.page = page;
        //Elements
        this.searchBox = page.getByRole('searchbox', { name: 'Search Wikipedia' });
        this.searchButton = page.getByRole('button', { name: 'Search' });
    }
    //Methods
    async goToUrl() {
        await this.page.goto(`${process.env.BaseURL1}`);
    }

    async searchWithKeyword(keyword: string) {
        await this.searchBox.click();
        await this.searchBox.fill(keyword);
        await this.searchButton.click();
    }
}

