//import { test, expect } from '@playwright/test';
// import { HomePage } from '../../src/pages/HomePage';
// import { FinalPage } from '../../src/pages/FinalPage';
// import { ResultsPage } from '../../src/pages/ResultsPage';
import { test} from '../../src/Fixtures/GlobalFixture';

// write test
test('optimised POM Playwright Test', async ({ page,homepage,resultsPage,finalpage }) => {
    await page.setViewportSize({ width: 1366, height: 728 });
    console.log(`Test Execution Started`);
    await homepage.goToUrl();
    await homepage.searchWithKeyword(`${process.env.SearchKeyword}`);
    await resultsPage.clickOnLink();
    await finalpage.validateLinkTitle();

});