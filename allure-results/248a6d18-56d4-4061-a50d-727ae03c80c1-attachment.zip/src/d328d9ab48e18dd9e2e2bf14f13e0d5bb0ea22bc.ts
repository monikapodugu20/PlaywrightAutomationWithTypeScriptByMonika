import { test, expect } from '@playwright/test';

// write test
test('loops in Playwright Test', async ({ page }) => {
  // go to website
  await page.goto('https://github.com/BakkappaN');

 const repolinks=await page.$$('.repo');
 for(const link of repolinks){
    const text=await link.innerText();
    console.log('loop1 : '+text);
  }
  
});