import { test, expect } from '@playwright/test';
import PostApiRequest from '../../test-data/api_requests/POST_request.json';

test.use({ baseURL: process.env.BASE_API_URL });//Accessing the base url from .env file
// write test
test('Create POST API Request using static file in Plywright Typescript', async ({ request }) => {
  
    const postapiresponse = await request.post('/booking', { data: PostApiRequest });
    const jsonpostapiresponse = await postapiresponse.json();//will convert response into json format
    console.log(`POST API Response : ${JSON.stringify(jsonpostapiresponse)}`);//will print after converting into string
    // Add assertions or further processing as needed
});